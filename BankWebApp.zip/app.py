from flask import Flask, render_template, request
import mysql.connector, random
from twilio.rest import Client

app = Flask(__name__)

# --- Twilio setup ---
account_sid = "ACe6d055ca92ae57aa1a687500b190ee18"
auth_token = "c734d5d73c3a8dca4cf59e1e9b6ab43c"
twilio_number = "+15017122661"
client = Client(account_sid, auth_token)

# --- Database connection ---
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Tamilselvan26",
    database="Bankaccount"
)
mycursor = mydb.cursor()

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/create', methods=['GET','POST'])
def create_account():
    if request.method == 'POST':
        name = request.form['name']
        dob = request.form['dob']
        mobile = request.form['mobile']
        adhar = request.form['adhar']
        pan = request.form['pan']
        address = request.form['address']
        pin = request.form['pin']
        deposit = float(request.form['deposit'])

        account_no = str(random.randint(1000000000, 9999999999))
        mycursor.execute('''INSERT INTO customers
            (account_no,name,dob,mobile,adhar,pan,Adress,pin,balance)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)''',
            (account_no,name,dob,mobile,adhar,pan,address,pin,deposit))
        mydb.commit()

        try:
            msg = f"Hello {name}, your new Bank Account {account_no} has been created successfully!"
            client.messages.create(to="+91"+mobile, from_=twilio_number, body=msg)
        except Exception as e:
            print("SMS not sent:", e)

        return render_template("result.html", message=f"Account {account_no} created successfully!")
    return render_template("create_account.html")

@app.route('/atm', methods=['GET','POST'])
def atm():
    if request.method == 'POST':
        acc = request.form['account']
        pin = request.form['pin']
        action = request.form['action']
        amount = float(request.form.get('amount', 0))

        mycursor.execute("SELECT balance,name FROM customers WHERE account_no=%s AND pin=%s",(acc,pin))
        user = mycursor.fetchone()

        if not user:
            return render_template("result.html", message="Invalid Account or PIN!")

        name, balance = user

        if action == 'deposit':
            new_balance = balance + amount
        elif action == 'withdraw':
            if balance < amount:
                return render_template("result.html", message="Insufficient balance!")
            new_balance = balance - amount
        else:
            return render_template("result.html", message=f"{name}, your balance is ₹{balance}")

        mycursor.execute("UPDATE customers SET balance=%s WHERE account_no=%s",(new_balance,acc))
        mydb.commit()
        return render_template("result.html", message=f"{action.title()} successful! New balance ₹{new_balance}")
    return render_template("atm.html")

if __name__ == '__main__':
    app.run(debug=True)
